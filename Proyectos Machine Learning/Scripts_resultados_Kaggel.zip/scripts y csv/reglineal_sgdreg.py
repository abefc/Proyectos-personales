import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Modelos de regresión
from sklearn.linear_model import Ridge, LinearRegression, SGDRegressor
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer  # Importar SimpleImputer
from sklearn.feature_selection import VarianceThreshold  # Para eliminación de características de baja varianza
from category_encoders import TargetEncoder  # Opcional, para técnicas avanzadas de encoding
import lightgbm as lgb  # Opcional, para modelos más avanzados

# 1. Cargar los conjuntos de datos
train_path = 'train.csv'  # Ruta al archivo de entrenamiento
test_path = 'test.csv'    # Ruta al archivo de prueba

# Leer los datos y considerar '-' como valor nulo
train_df = pd.read_csv(train_path, na_values=['–'])
test_df = pd.read_csv(test_path, na_values=['–'])

# Mostrar las primeras filas para verificar
print("Conjunto de Entrenamiento:")
print(train_df.head())
print("\nConjunto de Prueba:")
print(test_df.head())

# 2. Análisis de Correlación con Heatmap para Variables Numéricas
def plot_numeric_correlation_heatmap(df, numeric_cols, target_col, output_path):
    """
    Genera y guarda un heatmap de correlación para variables numéricas.
    """
    corr_matrix = df[numeric_cols + [target_col]].corr()
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='coolwarm')
    plt.title('Heatmap de Correlación entre Variables Numéricas y Precio')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"Heatmap de correlación numérica guardado como '{output_path}'.")

# Identificar variables numéricas excluyendo 'id' y 'price'
numeric_features_heatmap = train_df.select_dtypes(include=['int64', 'float64']).columns.tolist()
numeric_features_heatmap = [col for col in numeric_features_heatmap if col not in ['id', 'price']]

# Generar heatmap de correlación numérica
plot_numeric_correlation_heatmap(train_df, numeric_features_heatmap, 'price', 'heatmap_correlacion_numerica.png')

# 3. Análisis de Correlación Personalizada Incluyendo Variables Categóricas
from scipy.stats import pointbiserialr, chi2_contingency, pearsonr

def cramers_v(x, y):
    """
    Calcula el coeficiente de correlación Cramér's V entre dos variables categóricas.
    """
    confusion_matrix = pd.crosstab(x, y)
    chi2, p, dof, ex = chi2_contingency(confusion_matrix)
    n = confusion_matrix.sum().sum()
    phi2 = chi2 / n
    r, k = confusion_matrix.shape
    phi2corr = max(0, phi2 - ((k-1)*(r-1))/(n-1))
    rcorr = r - ((r-1)**2)/(n-1)
    kcorr = k - ((k-1)**2)/(n-1)
    denominator = min((kcorr-1), (rcorr-1))
    if denominator == 0:
        return np.nan
    return np.sqrt(phi2corr / denominator)

def calculate_custom_correlation_matrix(df, target_col, exclude_cols=[]):
    """
    Calcula una matriz de correlación personalizada que incluye variables numéricas y categóricas.
    """
    variables = df.columns.tolist()
    variables.remove('id')
    variables.remove(target_col)
    for col in exclude_cols:
        if col in variables:
            variables.remove(col)
    
    corr_matrix_custom = pd.DataFrame(index=variables, columns=variables)
    
    for var1 in variables:
        for var2 in variables:
            if var1 == var2:
                corr_matrix_custom.loc[var1, var2] = 1.0
            else:
                # Determinar el tipo de variable
                if df[var1].dtype in ['int64', 'float64'] and df[var2].dtype in ['int64', 'float64']:
                    # Correlación de Pearson
                    corr, _ = pearsonr(df[var1], df[var2])
                    corr_matrix_custom.loc[var1, var2] = round(corr, 2)
                elif (df[var1].dtype in ['int64', 'float64'] and df[var2].dtype == 'object') or \
                     (df[var1].dtype == 'object' and df[var2].dtype in ['int64', 'float64']):
                    # Correlación Punto-Biserial
                    try:
                        if df[var1].dtype == 'object':
                            x = LabelEncoder().fit_transform(df[var1].astype(str))
                            corr, _ = pointbiserialr(x, df[var2])
                        else:
                            x = LabelEncoder().fit_transform(df[var2].astype(str))
                            corr, _ = pointbiserialr(x, df[var1])
                        corr_matrix_custom.loc[var1, var2] = round(corr, 2)
                    except Exception as e:
                        corr_matrix_custom.loc[var1, var2] = np.nan
                elif df[var1].dtype == 'object' and df[var2].dtype == 'object':
                    # Cramér's V
                    corr = cramers_v(df[var1], df[var2])
                    corr_matrix_custom.loc[var1, var2] = round(corr, 2)
                else:
                    corr_matrix_custom.loc[var1, var2] = np.nan
    return corr_matrix_custom

# Calcular la matriz de correlación personalizada
corr_matrix_custom = calculate_custom_correlation_matrix(train_df, 'price')

# Mostrar la matriz de correlación personalizada
print("\nMatriz de Correlación Personalizada:")
print(corr_matrix_custom)

# Guardar la matriz de correlación personalizada como heatmap
def plot_custom_correlation_heatmap(corr_matrix, output_path):
    """
    Genera y guarda un heatmap para una matriz de correlación personalizada.
    """
    # Convertir a valores numéricos, manejando posibles NaN
    corr_numeric = corr_matrix.astype(float)
    
    plt.figure(figsize=(20, 18))
    sns.heatmap(corr_numeric, annot=True, fmt=".2f", cmap='coolwarm', linewidths=0.5)
    plt.title('Matriz de Correlación Personalizada')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"Heatmap de correlación personalizada guardado como '{output_path}'.")

plot_custom_correlation_heatmap(corr_matrix_custom, 'heatmap_correlacion_personalizada.png')

# 4. Preprocesamiento de Datos y Preparación para el Modelado
# Definir características y variable objetivo
X = train_df.drop(['id', 'price', 'model', 'fuel_type'], axis=1)
y = train_df['price']
X_test = test_df.drop(['id'], axis=1)

# Identificar las características categóricas y numéricas basadas en X
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
numerical_features = X.select_dtypes(include=['int64', 'float64']).columns.tolist()

# Imprimir las características categóricas y numéricas para verificar
print("\nCaracterísticas Categóricas:", categorical_features)
print("Características Numéricas:", numerical_features)

# 5. Manejo de Valores Faltantes
# Rellenar valores faltantes en variables categóricas con el valor más frecuente (mode)
for col in categorical_features:
    mode_value = X[col].mode()[0]
    X[col] = X[col].fillna(mode_value)
    X_test[col] = X_test[col].fillna(mode_value)
    print(f"Valores nulos en '{col}' han sido reemplazados por '{mode_value}'.")

# Rellenar valores faltantes en variables numéricas con la mediana
imputer_num = SimpleImputer(strategy='median')
X[numerical_features] = imputer_num.fit_transform(X[numerical_features])
X_test[numerical_features] = imputer_num.transform(X_test[numerical_features])

X.to_csv("train_nulos.csv", index=False)
X_test.to_csv("test_nulos.csv",index=False)

# 6. Eliminación de Ruido: Detección y Capping de Outliers en Características Numéricas
def cap_outliers(df, numerical_cols):
    """
    Capea los outliers en las columnas numéricas utilizando el método IQR.
    """
    for col in numerical_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        before = df[col].shape[0]
        df[col] = np.where(df[col] < lower_bound, lower_bound, df[col])
        df[col] = np.where(df[col] > upper_bound, upper_bound, df[col])
        after = df[col].shape[0]
        print(f"Outliers en '{col}' han sido capados: {before} -> {after}")
    return df

# Aplicar el capping de outliers
X = cap_outliers(X, numerical_features)
X_test = cap_outliers(X_test, numerical_features)

# 7. Definir los transformadores para las características
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

# 8. Dividir el conjunto de entrenamiento para validación
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# 9. Definir los modelos de regresión
# Modelo 1: Regresión Lineal
linear_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', LinearRegression())
])

# Modelo 2: Regresión con Descenso de Gradiente Estocástico (SGDRegressor)
sgd_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', SGDRegressor(max_iter=1000, tol=1e-3, random_state=42))
])

# 10. Entrenar los modelos
print("\nEntrenando el modelo de Regresión Lineal...")
linear_pipeline.fit(X_train, y_train)
print("Entrenando el modelo de SGD Regressor...")
sgd_pipeline.fit(X_train, y_train)

# 11. Evaluar los modelos
print("\nEvaluación de Modelos:")

# Predicciones y evaluación para Regresión Lineal
linear_pred = linear_pipeline.predict(X_val)
linear_rmse = np.sqrt(mean_squared_error(y_val, linear_pred))
print(f"Regresión Lineal RMSE: {linear_rmse:.2f}")

# Predicciones y evaluación para SGD Regressor
sgd_pred = sgd_pipeline.predict(X_val)
sgd_rmse = np.sqrt(mean_squared_error(y_val, sgd_pred))
print(f"SGD Regressor RMSE: {sgd_rmse:.2f}")

# 12. Seleccionar el mejor modelo (el que tenga menor RMSE)
if linear_rmse < sgd_rmse:
    best_model = linear_pipeline
    print("\nSeleccionando Regresión Lineal como el mejor modelo.")
else:
    best_model = sgd_pipeline
    print("\nSeleccionando SGD Regressor como el mejor modelo.")

# 13. Entrenar el mejor modelo con todo el conjunto de entrenamiento
best_model.fit(X, y)

# 14. Realizar predicciones sobre el conjunto de prueba
predictions = best_model.predict(X_test)

# Crear el DataFrame de resultados
output = pd.DataFrame({
    'id': test_df['id'],
    'price': predictions
})

# Asegurarse de que los precios sean positivos
output['price'] = output['price'].apply(lambda x: max(x, 0))

# 15. Guardar las predicciones en un archivo CSV
output_path = 'predicciones.csv'
output.to_csv(output_path, index=False)
print(f"\nLas predicciones han sido guardadas en '{output_path}'")
