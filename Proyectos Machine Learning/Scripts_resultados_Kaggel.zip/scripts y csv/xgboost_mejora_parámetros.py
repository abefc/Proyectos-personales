import numpy as np
import pandas as pd
import warnings

# Modelos
from xgboost import XGBRegressor

# Herramientas de Scikit-learn
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

warnings.simplefilter('ignore')

# =============================================================================
# 1. Lectura de Datos
# =============================================================================
train_path = 'train.csv'
test_path  = 'test.csv'

train_df = pd.read_csv(train_path, na_values=['–'])
test_df  = pd.read_csv(test_path, na_values=['–'])

print(f"Shape de train: {train_df.shape}")
print(f"Shape de test:  {test_df.shape}")

# =============================================================================
# 2. Quitamos filas de train que no tengan 'price' (variable objetivo)
# =============================================================================
train_df = train_df.dropna(subset=['price']).copy()

# =============================================================================
# 3. Definir X e y (drop de columnas irrelevantes o problemáticas)
# =============================================================================
X = train_df.drop(columns=['id', 'price', 'model', 'fuel_type'], errors='ignore').copy()
y = train_df['price'].copy()

# Para test, dropeamos también las columnas que no queramos
X_test = test_df.drop(columns=['id', 'model', 'fuel_type'], errors='ignore').copy()

# =============================================================================
# 4. Columnas categóricas y numéricas
# =============================================================================
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
numeric_features     = X.select_dtypes(include=['int64','float64']).columns.tolist()

print("\nCategóricas:", categorical_features)
print("Numéricas:", numeric_features)

# =============================================================================
# 5. Rellenar NaNs en categóricas con la moda
# =============================================================================
for col in categorical_features:
    mode_value = X[col].dropna().mode()
    if len(mode_value) == 0:
        # Columna totalmente vacía
        X[col].fillna('Desconocido', inplace=True)
        if col in X_test.columns:
            X_test[col].fillna('Desconocido', inplace=True)
    else:
        X[col].fillna(mode_value[0], inplace=True)
        if col in X_test.columns:
            X_test[col].fillna(mode_value[0], inplace=True)

# =============================================================================
# 6. Función para "capar" outliers (IQR)
# =============================================================================
def cap_outliers(df, cols):
    for c in cols:
        Q1 = df[c].quantile(0.25)
        Q3 = df[c].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df[c] = np.where(df[c] < lower, lower, df[c])
        df[c] = np.where(df[c] > upper, upper, df[c])
    return df

X = cap_outliers(X, numeric_features)
X_test = cap_outliers(X_test, numeric_features)

# =============================================================================
# 7. Asegurar que Train y Test tengan las mismas columnas
# =============================================================================
common_cols = set(X.columns).intersection(set(X_test.columns))
X = X[list(common_cols)].copy()
X_test = X_test[list(common_cols)].copy()

# =============================================================================
# 8. Dividir train en Entrenamiento/Validación
# =============================================================================
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\nTamaño de X_train: {X_train.shape}, X_val: {X_val.shape}")

# =============================================================================
# 9. Definir Pipeline de Preprocesamiento + XGBoost
# =============================================================================
preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ]), numeric_features),
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('ohe', OneHotEncoder(handle_unknown='ignore'))
        ]), categorical_features)
    ],
    remainder='drop'
)

xgb_model = XGBRegressor(
    objective='reg:squarederror',
    random_state=42,
    n_jobs=-1
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('regressor', xgb_model)
])

# =============================================================================
# 10. Búsqueda Aleatoria de Hiperparámetros (mejora)
# =============================================================================
# Ajusta el rango de hiperparámetros a tu gusto
param_dist = {
    'regressor__n_estimators': [200, 300, 500],
    'regressor__learning_rate': [0.01, 0.05, 0.1],
    'regressor__max_depth': [3, 5, 7]
}

from sklearn.model_selection import RandomizedSearchCV

random_search = RandomizedSearchCV(
    estimator=pipeline,
    param_distributions=param_dist,
    n_iter=5,  # probará 5 combinaciones aleatorias
    scoring='neg_root_mean_squared_error',
    cv=3,    # 3-fold CV
    random_state=42,
    verbose=1,
    n_jobs=-1
)

print("\nIniciando RandomizedSearchCV (mini)...")
random_search.fit(X_train, y_train)

print("\nMejores hiperparámetros encontrados:")
print(random_search.best_params_)

# Evaluar RMSE en conjunto de validación
best_pipeline = random_search.best_estimator_

y_pred_val = best_pipeline.predict(X_val)
val_rmse = np.sqrt(mean_squared_error(y_val, y_pred_val))
print(f"\nRMSE en Validación con mejor combinación: {val_rmse:.2f}")

# =============================================================================
# 11. Entrenar con TODOS los datos de train
# =============================================================================
best_pipeline.fit(X, y)

# =============================================================================
# 12. Predicciones en X_test
# =============================================================================
test_pred = best_pipeline.predict(X_test)
test_pred = np.clip(test_pred, 0, None)

# Si 'id' existe en test original, la rescatamos
submission = pd.DataFrame({
    'id': test_df['id'],
    'price': test_pred
})

submission.to_csv('predicciones_xgb_mejorado.csv', index=False)
print("\nPredicciones guardadas en 'predicciones_xgb_mejorado.csv'. ¡Listo!") 
