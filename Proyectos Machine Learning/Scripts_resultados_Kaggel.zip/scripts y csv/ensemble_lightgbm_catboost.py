import numpy as np
import pandas as pd
import re
import warnings

# Modelos
import lightgbm as lgb
from lightgbm import early_stopping, log_evaluation
from catboost import CatBoostRegressor
from sklearn.linear_model import SGDRegressor

# Herramientas
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer  # Imputación de valores faltantes

warnings.simplefilter('ignore')

# =============================================================================
# 1. Lectura de datos
# =============================================================================

train_path = 'train.csv'
test_path  = 'test.csv'

train_df = pd.read_csv(train_path, na_values=['–'])
test_df  = pd.read_csv(test_path, na_values=['–'])

print(f"Shape de train: {train_df.shape}")
print(f"Shape de test:  {test_df.shape}")

# =============================================================================
# 2. Función para agrupar categorías raras y convertir a 'category'
# =============================================================================
def reduce_and_cat(df, thresh=100):
    """
    Reemplaza categorías con frecuencia < thresh por 'noise'
    en columnas especificadas, rellena nulos con 'missing'
    y convierte a 'category'.
    """
    # Ajusta las columnas según tu dataset
    cols_to_reduce = ['model', 'engine', 'transmission', 'ext_col', 'int_col']
    cat_cols = ['brand', 'model', 'fuel_type', 'engine', 'transmission', 'ext_col', 'int_col', 'accident', 'clean_title']

    for col in cols_to_reduce:
        if col in df.columns:
            freq = df[col].value_counts(dropna=False)
            rare_labels = freq[freq < thresh].index
            df.loc[df[col].isin(rare_labels), col] = 'noise'

    for c in cat_cols:
        if c in df.columns:
            df[c] = df[c].fillna('missing')   # nulos => 'missing'
            df[c] = df[c].astype('category')  # convertir a tipo category

    return df

# Aplicamos la función a train y test con el mismo threshold
train_df = reduce_and_cat(train_df, thresh=100)
test_df  = reduce_and_cat(test_df, thresh=100)

# =============================================================================
# 3. Definir X, y
# =============================================================================
X_train_full = train_df.drop(columns=['id', 'price'], errors='ignore')
y_train_full = train_df['price']

X_test = test_df.drop(columns=['id'], errors='ignore')

print("\nColumnas de X_train_full:", X_train_full.columns.tolist())

# =============================================================================
# 4. Definir un K-Fold general y una función para entrenar y predecir
# =============================================================================
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def cross_validate_and_predict(model, X, y, X_test, n_splits=5,
                               early_stop_rounds=100, random_state=42,
                               use_cat_features=False):
    """
    Entrena con KFold n_splits. Para cada fold entrena un modelo
    y predice en X_test, luego hace la media de las predicciones.
    """
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    test_preds_folds = np.zeros((len(X_test), n_splits), dtype=np.float32)

    for fold, (trn_idx, val_idx) in enumerate(kf.split(X, y)):
        print(f"\n=== Fold {fold+1} de {n_splits} ===")
        X_trn, X_val = X.iloc[trn_idx], X.iloc[val_idx]
        y_trn, y_val = y.iloc[trn_idx], y.iloc[val_idx]

        # Entrenamiento del modelo
        if isinstance(model, lgb.LGBMRegressor):
            # LightGBM con callbacks para early stopping
            callbacks = [
                early_stopping(stopping_rounds=early_stop_rounds),
                log_evaluation(period=100)  # Opcional: para imprimir cada 100 iteraciones
            ]
            model.fit(
                X_trn, y_trn,
                eval_set=[(X_val, y_val)],
                callbacks=callbacks,
                # verbose=False
            )

        elif isinstance(model, CatBoostRegressor):
            # CatBoost con early_stopping
            cat_params = {
                'silent': True,
                'early_stopping_rounds': early_stop_rounds,
            }
            if use_cat_features:
                # Extraemos las columnas categóricas
                cat_features_idx = [
                    X_trn.columns.get_loc(c)
                    for c in X_trn.select_dtypes(include='category').columns
                ]
                model.fit(
                    X_trn, y_trn,
                    eval_set=(X_val, y_val),
                    cat_features=cat_features_idx,
                    **cat_params
                )
            else:
                model.fit(
                    X_trn, y_trn,
                    eval_set=(X_val, y_val),
                    **cat_params
                )

        else:
            # Para otros modelos (ej. SGDRegressor o Pipeline)
            model.fit(X_trn, y_trn)

        # Predicción en la parte de validación, para mostrar RMSE
        val_pred = model.predict(X_val)
        fold_rmse_score = rmse(y_val, val_pred)
        print(f"Fold {fold+1} RMSE: {fold_rmse_score:.2f}")

        # Predicción en X_test
        test_preds_folds[:, fold] = model.predict(X_test)

    # Promediamos las predicciones
    test_preds_mean = np.mean(test_preds_folds, axis=1)
    return test_preds_mean

# =============================================================================
# 5. Definir los Preprocesadores y Parámetros de los Modelos
# =============================================================================

# Identificar características categóricas y numéricas
categorical_features = X_train_full.select_dtypes(include=['category']).columns.tolist()
numeric_features = X_train_full.select_dtypes(include=['int64', 'float64']).columns.tolist()

# Definir transformadores para imputar valores faltantes
categorical_imputer = SimpleImputer(strategy='most_frequent')
numerical_imputer = SimpleImputer(strategy='median')

# Codificador para variables categóricas: OneHotEncoder con handle_unknown='ignore'
categorical_encoder = OneHotEncoder(handle_unknown='ignore')

# Crear preprocesador
preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline(steps=[('imputer', numerical_imputer), ('scaler', StandardScaler())]), numeric_features),
        ('cat', Pipeline(steps=[('imputer', categorical_imputer), ('encoder', categorical_encoder)]), categorical_features)
    ],
    remainder='passthrough'  # Dejar pasar otras columnas si las hubiera
)

# Parámetros de LightGBM y CatBoost
lgb_params = {
    'n_estimators': 6000,
    'learning_rate': 0.0015,
    'num_leaves': 80,
    'max_depth': 60,
    'subsample': 0.6,
    'colsample_bytree': 0.6,
    'reg_alpha': 0.1,
    'reg_lambda': 0.3,
    'random_state': 42
}

cat_params = {
    'iterations': 5000,
    'learning_rate': 0.02,
    'depth': 11,
    'l2_leaf_reg': 0.3,
    'random_seed': 42,
    'task_type': 'GPU',  # si GPU está disponible
}

# =============================================================================
# 6. Entrenar y predecir
# =============================================================================

print("\nEntrenando LightGBM con CV y early stopping...\n")
lgb_model = lgb.LGBMRegressor(**lgb_params)
lgb_preds = cross_validate_and_predict(
    lgb_model,
    X_train_full,
    y_train_full,
    X_test,
    n_splits=5,
    early_stop_rounds=200,
    random_state=42
)
print("\nEntrenando CatBoost con CV y early stopping...\n")
cat_model = CatBoostRegressor(**cat_params)
cat_preds = cross_validate_and_predict(
    cat_model,
    X_train_full,
    y_train_full,
    X_test,
    n_splits=5,
    early_stop_rounds=200,
    random_state=42,
    use_cat_features=True
)

# =============================================================================
# 7. Blending final
# =============================================================================
final_preds = 0.5 * lgb_preds + 0.5 * cat_preds
final_preds = np.clip(final_preds, 0, None)

# =============================================================================
# 8. Generar submission
# =============================================================================
sample_sub = pd.read_csv('sample_submission.csv')
sample_sub['price'] = final_preds
sample_sub.to_csv('submission_ensemble.csv', index=False)

print("\n¡Archivo 'submission_ensemble.csv' generado! Súbelo a Kaggle para comprobar tu puntuación.")