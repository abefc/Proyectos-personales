import numpy as np
import pandas as pd
import warnings
import matplotlib.pyplot as plt

# Modelos
from xgboost import XGBRegressor

# Herramientas de Scikit-learn
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, PowerTransformer
from sklearn.impute import SimpleImputer

warnings.simplefilter('ignore')

# =============================================================================
# 1. Lectura de Datos
# =============================================================================
train_path = 'train.csv'
test_path  = 'test.csv'

train_df = pd.read_csv(train_path, na_values=['–'])
test_df  = pd.read_csv(test_path, na_values=['–'])

print(f"Shape de train: {train_df.shape}")
print(f"Shape de test:  {test_df.shape}")

# =============================================================================
# 2. Ingeniería de Características
# =============================================================================
def feature_engineering(df):
    """
    - Crea 'car_age' = 2025 - model_year
    - Extrae engine_hp, engine_displacement, engine_cylinders de 'engine'
    - Extrae is_automatic a partir de 'transmission'
    - Extrae had_accidents a partir de 'accident'
    - Elimina la columna 'engine'
    """
    # 1) Crear la edad del coche
    if 'model_year' in df.columns:
        df['car_age'] = 2025 - df['model_year']
    else:
        df['car_age'] = np.nan

    # 2) Extraer información del motor con regex
    if 'engine' in df.columns:
        df['engine'] = df['engine'].astype(str)
        import re
        engine_regex = (
            r'(?P<engine_hp>\d+\.?\d*)HP.*?'
            r'(?P<engine_displacement>\d+\.?\d*)L.*?'
            r'(?P<engine_cylinders>\d+) Cylinder'
        )
        extracted = df['engine'].str.extract(engine_regex, expand=True)
        df['engine_hp'] = pd.to_numeric(extracted['engine_hp'], errors='coerce')
        df['engine_displacement'] = pd.to_numeric(extracted['engine_displacement'], errors='coerce')
        df['engine_cylinders'] = pd.to_numeric(extracted['engine_cylinders'], errors='coerce')
        df.drop(columns=['engine'], inplace=True, errors='ignore')
    else:
        df['engine_hp'] = np.nan
        df['engine_displacement'] = np.nan
        df['engine_cylinders'] = np.nan

    # 3) is_automatic
    if 'transmission' in df.columns:
        df['is_automatic'] = df['transmission'].str.contains('A/T|Automatic', na=False).astype(int)
    else:
        df['is_automatic'] = np.nan

    # 4) had_accidents
    if 'accident' in df.columns:
        df['had_accidents'] = df['accident'].str.contains('At least 1 accident|damage reported', na=False).astype(int)
        df.drop(columns=['accident'], inplace=True, errors='ignore')
    else:
        df['had_accidents'] = np.nan

    return df

# Aplicamos la ingeniería de características en train y test
train_df = feature_engineering(train_df)
test_df  = feature_engineering(test_df)

# =============================================================================
# 3. Eliminar filas sin 'price' y definir X, y
# =============================================================================
train_df = train_df.dropna(subset=['price']).copy()
X = train_df.drop(columns=['id','price','model','fuel_type', 'model_year'], errors='ignore').copy()
y = train_df['price'].copy()

X_test = test_df.drop(columns=['id','model','fuel_type', 'model_year'], errors='ignore').copy()

# =============================================================================
# 4. Función para agrupar categorías raras
# =============================================================================
def group_rare_categories(df, col, min_count=50):
    """
    Reemplaza con la etiqueta 'Rare' todas las categorías de la columna 'col'
    que aparezcan menos de 'min_count' veces.
    """
    freq = df[col].value_counts()
    rare_cats = freq[freq < min_count].index
    df[col] = df[col].replace(rare_cats, 'Rare')


# =============================================================================
# 5. Separar columnas numéricas y categóricas
# =============================================================================
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
numeric_features     = X.select_dtypes(include=['int64','float64']).columns.tolist()

print("\nColumnas categóricas:", categorical_features)
print("Columnas numéricas:", numeric_features)

# =============================================================================
# 5a. (Opcional) Agrupar categorías raras en cada columna categórica
# =============================================================================
for col in categorical_features:
    group_rare_categories(X, col, min_count=50)  # umbral ajustable
    if col in X_test.columns:
        group_rare_categories(X_test, col, min_count=50)

# =============================================================================
# 6. Imputar manualmente los NaNs en las categóricas con la moda
# =============================================================================
for col in categorical_features:
    mode_value = X[col].dropna().mode()
    if len(mode_value) == 0:
        X[col].fillna('Desconocido', inplace=True)
        if col in X_test.columns:
            X_test[col].fillna('Desconocido', inplace=True)
    else:
        X[col].fillna(mode_value[0], inplace=True)
        if col in X_test.columns:
            X_test[col].fillna(mode_value[0], inplace=True)

# =============================================================================
# 7. Función para "capar" outliers en las numéricas (IQR)
# =============================================================================
def cap_outliers(df, cols):
    for c in cols:
        Q1 = df[c].quantile(0.25)
        Q3 = df[c].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df[c] = np.where(df[c] < lower, lower, df[c])
        df[c] = np.where(df[c] > upper, upper, df[c])
    return df

X = cap_outliers(X, numeric_features)
X_test = cap_outliers(X_test, numeric_features)

# =============================================================================
# 8. Ajustar para que train y test tengan las mismas columnas
# =============================================================================
common_cols = set(X.columns).intersection(set(X_test.columns))
X = X[list(common_cols)].copy()
X_test = X_test[list(common_cols)].copy()

# =============================================================================
# 9. Mostramos un describe() de X para ver resumen de variables numéricas
# =============================================================================
print("\nDescripción de X (numéricas):")
print(X.describe())

# =============================================================================
# 10. Separar en Entrenamiento / Validación para ver RMSE local
# =============================================================================
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTamaño de X_train: {X_train.shape}, X_val: {X_val.shape}")

# =============================================================================
# 11. Construir el pipeline de preprocesamiento + XGBoost
# =============================================================================
from sklearn.preprocessing import PowerTransformer

num_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

cat_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('ohe', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', num_pipeline, numeric_features),
        ('cat', cat_pipeline, categorical_features)
    ],
    remainder='drop'
)

xgb_model = XGBRegressor(
    objective='reg:squarederror',
    random_state=42,
    n_jobs=-1
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('regressor', xgb_model)
])

# =============================================================================
# 12. Definir un RandomizedSearchCV para afinar hiperparámetros
# =============================================================================
from sklearn.model_selection import RandomizedSearchCV

param_dist = {
    'regressor__n_estimators': [200, 300, 500],
    'regressor__learning_rate': [0.01, 0.05, 0.1],
    'regressor__max_depth': [3, 5, 7],
}

random_search = RandomizedSearchCV(
    estimator=pipeline,
    param_distributions=param_dist,
    n_iter=20,  # más combinaciones aleatorias
    scoring='neg_root_mean_squared_error',
    cv=3,
    random_state=42,
    verbose=1,
    n_jobs=-1
)

print("\nIniciando RandomizedSearchCV con mejoras de preprocesado...")
random_search.fit(X_train, y_train)

best_pipeline = random_search.best_estimator_
print("\nMejores hiperparámetros:", random_search.best_params_)

# RMSE en validación
y_pred_val = best_pipeline.predict(X_val)
val_rmse = np.sqrt(mean_squared_error(y_val, y_pred_val))
print(f"RMSE en Validación con mejor combinación: {val_rmse:.2f}")

# =============================================================================
# 13. Entrenar con TODOS los datos
# =============================================================================
best_pipeline.fit(X, y)

# =============================================================================
# 14. Importancia de Variables en XGBoost
# =============================================================================
xgb_best = best_pipeline.named_steps['regressor']
importances = xgb_best.feature_importances_

cat_pipeline_fitted = best_pipeline.named_steps['preprocessor'].named_transformers_['cat']
ohe = cat_pipeline_fitted.named_steps['ohe']
cat_cols_transformed = ohe.get_feature_names_out(categorical_features)

final_num_cols = numeric_features
feature_names = list(final_num_cols) + list(cat_cols_transformed)

if len(feature_names) != len(importances):
    print(f"\n[ADVERTENCIA] # de feature_names ({len(feature_names)}) != importances ({len(importances)})")
else:
    feat_imp = sorted(zip(feature_names, importances), key=lambda x: x[1], reverse=True)

    print("\nTop 15 Features más importantes (según XGBoost):")
    for i, (fname, imp) in enumerate(feat_imp[:15], start=1):
        print(f"{i:2d}. {fname:30s} => {imp:.4f}")

    plt.figure(figsize=(8, 10))
    feats, imps = zip(*feat_imp[:30])
    plt.barh(feats[::-1], imps[::-1], color='royalblue')
    plt.xlabel("Importancia")
    plt.title("Importancia de variables - XGBoost (Top 30)")
    plt.tight_layout()
    plt.show()

# =============================================================================
# 15. Predicción en X_test y generamos CSV final
# =============================================================================
test_pred = best_pipeline.predict(X_test)
test_pred = np.clip(test_pred, 0, None)

submission = pd.DataFrame({
    'id': test_df['id'],
    'price': test_pred
})

submission.to_csv('predicciones_xgb_mejorado.csv', index=False)
print("\nPredicciones guardadas en 'predicciones_xgb_mejorado.csv'. ¡Listo!")
