import numpy as np
import pandas as pd
import warnings

# Modelos
from xgboost import XGBRegressor

# Herramientas de Scikit-learn
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

warnings.simplefilter('ignore')


# =============================================================================
# 1. Lectura de Datos
# =============================================================================
train_path = 'train.csv'
test_path  = 'test.csv'

train_df = pd.read_csv(train_path, na_values=['–'])
test_df  = pd.read_csv(test_path, na_values=['–'])

print(f"Shape de train: {train_df.shape}")
print(f"Shape de test:  {test_df.shape}")


# =============================================================================
# 2. Preparamos el DataFrame para el modelado
#    (quitando gráficas y correlaciones, como solicitaste)
# =============================================================================

# Usaremos la columna 'price' como nuestra variable objetivo 'y'.
# En test, la columna 'price' no existe, así que solo la usaremos en train.

# Asegurarnos de que no haya filas sin 'price'
train_df = train_df.dropna(subset=['price']).copy()

# Definir X e y según las columnas que queramos usar.
# Como ejemplo, quitamos 'id', 'price' y (opcionalmente) otras que no deseemos.
# Ajusta según tus necesidades. Aquí quitamos 'model' y 'fuel_type' para imitar tu ejemplo.
X = train_df.drop(['id', 'price', 'model', 'fuel_type'], axis=1, errors='ignore').copy()
y = train_df['price'].copy()

# Para el test, quitamos 'id' y también las columnas que no usemos
X_test = test_df.drop(['id', 'model', 'fuel_type'], axis=1, errors='ignore').copy()

# =============================================================================
# 3. Identificar las características categóricas y numéricas
# =============================================================================
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
numeric_features     = X.select_dtypes(include=['int64','float64']).columns.tolist()

print("\nCaracterísticas Categóricas:", categorical_features)
print("Características Numéricas:", numeric_features)


# =============================================================================
# 4. Manejo de Valores Faltantes (Imputación)
# =============================================================================

# a) Para las categóricas, rellenamos con la moda (valor más frecuente)
for col in categorical_features:
    mode_value = X[col].dropna().mode()
    if len(mode_value) == 0:
        # Si la columna entera es NaN, asignamos 'Desconocido'
        X[col].fillna('Desconocido', inplace=True)
        X_test[col].fillna('Desconocido', inplace=True)
    else:
        X[col].fillna(mode_value[0], inplace=True)
        if col in X_test.columns:
            X_test[col].fillna(mode_value[0], inplace=True)

# b) Para las numéricas, usaremos un SimpleImputer (más adelante en la pipeline).
#    No obstante, también podemos hacer una imputación manual si lo deseas.

# =============================================================================
# 5. Función para 'capar' outliers en las numéricas (IQR)
# =============================================================================
def cap_outliers(df, cols):
    """
    Capea outliers a [Q1-1.5IQR, Q3+1.5IQR] en columnas numéricas.
    """
    for c in cols:
        Q1 = df[c].quantile(0.25)
        Q3 = df[c].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df[c] = np.where(df[c] < lower, lower, df[c])
        df[c] = np.where(df[c] > upper, upper, df[c])
    return df

X = cap_outliers(X, numeric_features)
# Para X_test también, aunque a veces no se capan los outliers en test;
# lo hacemos aquí por consistencia.
X_test = cap_outliers(X_test, numeric_features)


# =============================================================================
# 6. Asegurar que Train y Test tengan las mismas columnas
# =============================================================================
common_cols = set(X.columns).intersection(set(X_test.columns))
X = X[list(common_cols)].copy()
X_test = X_test[list(common_cols)].copy()

# =============================================================================
# 7. Dividir train_df en Entrenamiento/Validación para medir RMSE
# =============================================================================
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\nTamaño de X_train: {X_train.shape}, X_val: {X_val.shape}")


# =============================================================================
# 8. Definir la pipeline de preprocesamiento + XGBoost
# =============================================================================
# - numeric => median imputer, standard scaler
# - categorical => one-hot-encoder

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ]), numeric_features),
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),  # fallback
            ('ohe', OneHotEncoder(handle_unknown='ignore'))
        ]), categorical_features)
    ],
    remainder='drop'
)

xgb_model = XGBRegressor(
    n_estimators=300,
    learning_rate=0.1,
    max_depth=5,
    random_state=42,
    n_jobs=-1
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('regressor', xgb_model)
])


# =============================================================================
# 9. Entrenar y Evaluar RMSE
# =============================================================================
pipeline.fit(X_train, y_train)

y_pred_val = pipeline.predict(X_val)
val_rmse = np.sqrt(mean_squared_error(y_val, y_pred_val))
print(f"\nRMSE en Validación: {val_rmse:.2f}")

# =============================================================================
# 10. Entrenar con TODOS los datos de train (X, y)
# =============================================================================
pipeline.fit(X, y)

# =============================================================================
# 11. Predecir en X_test y generar archivo CSV final
# =============================================================================
test_pred = pipeline.predict(X_test)

# Asegurarnos de no tener valores negativos
test_pred = np.clip(test_pred, 0, None)

# Si 'id' existe en test original, la rescatamos para la submisión
submission = pd.DataFrame({
    'id': test_df['id'],
    'price': test_pred
})

submission.to_csv('predicciones_xgb.csv', index=False)
print("\nPredicciones guardadas en 'predicciones_xgb.csv'.")
